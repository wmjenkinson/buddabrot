/*
 * application_mode_routine.h
 *
 * Created: 16/06/2017 13:24:19
 *  Author: INTERNET
 */ 
/*
 * Copyright (c) 2017 Queens University Belfast.
 * All rights reserved. 
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR serviceS; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
 * OF SUCH DAMAGE.
 *
 * This file is part of the Darkness Real-time Kernel.
 * 
 * Author: William Jenkinson <wm.jenkinson@hotmail.com */
/*
 * buddahbrot.h
 *
 * Created: 10/04/2017 16:59:18
 *  Author: INTRENET
 */ 


#ifndef BUDDAHBROT_H_
#define BUDDAHBROT_H_

	// Includes
    #include <stdio.h>
    #include <stdlib.h>
    #include <math.h>
    #include <stdint.h> // uint16_t uint32_t
    #include <string.h> // memset()
	#include "float.h"
		
	extern unsigned char * display_ram;
	extern unsigned char * return_dsp_ram_addr;
    
	// Input parameters
    double    gnWorldMinX        = -2.102613; // WorldW = MaxX-MinX = 3.303226
    double    gnWorldMaxX        =  1.200613;
    double    gnWorldMinY        = -1.237710; // WorldH = MaxY-MinY = 2.47742 
    double    gnWorldMaxY        =  1.239710;

    int       gnMaxDepth         = 200; // max number of iterations == # of pixels to plot per complex number
    int       gnWidth            = 320; // image width
    int       gnHeight           = 240; // image height
    int       gnScale            = 10;  // not sub-sample, but sub-divide world width / (pixel width * scale)

    bool      gbAutoBrightness   = true;
    // Default MaxDepth = 1000 @ 1042x768 has a maximum greyscale intensity = 5010 -> 230/5010 = filter out bottom 4.590808% of image as black
    int       gnGreyscaleBias    = -230; // color pixel = (greyscale pixel + bias) * scale = 5010 - 230 = 4780

    float     gnScaleR           = 0.39f; // Default: (5010 - 230) * 0.09 = 430.2
    float     gnScaleG           = 0.31f; // Default: (5010 - 230) * 0.11 = 525.8
    float     gnScaleB           = 0.48f; // Default: (5010 - 230) * 0.18 = 860.4

    bool      gbVerbose          = false;
    bool      gbSaveRawGreyscale = true ;
    bool      gbRotateOutput     = true ;
    bool      gbSaveBMP          = true ;

    // Calculated/Cached
    uint32_t  gnImageArea        =    0; // image width * image height

    // Output
    uint16_t *gpGreyscaleTexels  = NULL; // [ height ][ width ] 16-bit greyscale
    uint8_t  *gpChromaticTexels  = NULL; // [ height ][ width ] 24-bit RGB

    const int BUFFER_BACKSPACE   = 64;
    char      gaBackspace[ 64 ];



// Implementation _________________________________________________________________ 
// ========================================================================
static void AllocImageMemory( const int width, const int height )
{
    gnImageArea = width * height;

    const size_t nGreyscaleBytes = gnImageArea  * sizeof( uint16_t );
	
    gpGreyscaleTexels = (uint16_t*) api_calloc(1, nGreyscaleBytes );          // 1x 16-bit channel: W
}



// @param greyscale  Source greyscale texels to read
// @param chromatic_ Destination chromatic texels to write
// ========================================================================
static void Image_Greyscale16bitToColor24bit(
	
	
    const uint16_t* greyscale, const int width, const int height,
    /* */ uint8_t * chromatic_,
    const int bias, const double scaleR, const double scaleG, const double scaleB )
{
    const uint16_t *pSrc = greyscale;
	
	display_ram = return_dsp_ram_addr;
		
    for (int x = 0; x < gnHeight; x++) {
	    for (int y = 0; y < gnWidth; y++) {
			
			int i = *pSrc++ + bias  ; // low pass noise filter
		    int r = (int)(i * scaleR);
			int g = (int)(i * scaleG);
			int b = (int)(i * scaleB);

			if (r > 255) r = 255; if (r < 0) r = 0;
			if (g > 255) g = 255; if (g < 0) g = 0;
			if (b > 255) b = 255; if (b < 0) b = 0;

			unsigned short d;
        
			// Code to convert from 24-bit to 16 bit
			r = (unsigned short)((double)(r * 31) / 255.0);
			g = (unsigned short)((double)(g * 63) / 255.0);
			b = (unsigned short)((double)(b * 31) / 255.0);
			d = (r << 11) | (g << 5) | (b << 0);

			drawPixel(x, y, d);
			
			unsigned char hi_byte = d >> 8;
			unsigned char low_byte = d;
				
			* display_ram = hi_byte;	display_ram++;
			* display_ram = low_byte;	display_ram++; 

		}
    }
}


static void Image_Greyscale16bitRotateRight( const uint16_t *input, const int width, const int height, uint16_t *output_ )
{
	// Source row[y] -> Dest col[ h-y-1 ]
	//   Source   ->
	//   0 1 2 4     5 0
	//   5 6 7 8     6 1
	//               7 2
	//               8 4

	// Linearized 1D memory Layout for Source and Dest
	// [    0*w] [1] [2] .. [1w-1]
	// [    1*w] ...........[2w-1]
	// [    2*w] ...........[3w-1]
	// :                         :
	// [(h-1)*w] .........  [hw-1]

	for( int y = 0; y < height; y++ )
	{
		const uint16_t *pSrc = input   + ((width   ) * y);
		/* */ uint16_t *pDst = output_ + ((height-1) - y);

		for( int x = 0; x < width; x++ )
		{
			*pDst = *pSrc;

			pSrc++;
			pDst += height;
		}
	}
}



// ========================================================================
static char * itoaComma(size_t n, char * output_){
	
	output_ = NULL;
	
    const  int SIZE = 32;
    static char   buffer[ 32 ];
    /* */  char  *p = buffer + 32-1;
    *p-- = 0;

    while( n >= 1000 )
    {
        *p-- = '0' + (n % 10); n /= 10;
        *p-- = '0' + (n % 10); n /= 10;
        *p-- = '0' + (n % 10); n /= 10;
        *p-- = ','                    ;
    }

    /*      */ { *p-- = '0' + (n % 10); n /= 10; }
    if( n > 0) { *p-- = '0' + (n % 10); n /= 10; }
    if( n > 0) { *p-- = '0' + (n % 10); n /= 10; }

    if( output_ )
    {
        char   *pEnd = buffer + SIZE - 1;
        size_t  nLen = pEnd - p; 
        memcpy( output_, p+1, nLen );
    }

    return ++p;
}


static inline void plot( double wx, double wy, double sx, double sy, uint16_t *texels, const int width, const int height, const int maxdepth )
{
    double  r = 0., i = 0.; // Zn   current Complex< real, imaginary >
    double  s     , j     ; // Zn+1 next    Complex< real, imaginary >
    int     u     , v     ; // texel coords

    for( int depth = 0; depth < maxdepth; depth++ )
    {
        s = (r*r - i*i) + wx;
        j = (2.0*r*i)   + wy;

        r = s;
        i = j;

        if ((r*r + i*i) > 4.0 ) // escapes to infinity, don't render
            return;

        u = (int) ((r - gnWorldMinX) * sx); // texel x
        v = (int) ((i - gnWorldMinY) * sy); // texel y

        if( (u < width) && (v < height) && (u >= 0) && (v >= 0) )
            texels[ (v * width) + u ]++;
   }
}

unsigned int progress = 0;
static void verbrose(int nCol, int nRow){
	
	char percentage_string[14] = {0};
		
	extern void ftoa(double, char *, int);			
	float percentage_complete = 100.0 / ((float)(nCol * nRow) / progress); 
		
	ftoa(percentage_complete, percentage_string, 3); 
	drawString(135, 125, &percentage_string[0], ILI9341_WHITE, ILI9341_DARKCYAN, 2);
}


// @return Number of input scaled pixels (Not uber total of all pixels processed)
// ========================================================================
int Buddhabrot(void);
int Buddhabrot(void){
    
	extern void refresh_dsp(void);
	
	if( gnScale < 0)
        gnScale = 1;

    const size_t nCol = gnWidth  * gnScale ; // scaled width
    const size_t nRow = gnHeight * gnScale ; // scaled height

    /* */ size_t iCel = 0                  ; // Progress status for percent compelete
    const size_t nCel = nCol     * nRow    ; // scaled width * scaled height;

    const double nWorldW = gnWorldMaxX - gnWorldMinX;
    const double nWorldH = gnWorldMaxY - gnWorldMinY;

    // Map Source (world space) to Pixels (image space)
    const double nWorld2ImageX = (double)(gnWidth  - 1.) / nWorldW;
    const double nWorld2ImageY = (double)(gnHeight - 1.) / nWorldH;

    const double dx = nWorldW / (nCol - 1.0);
    const double dy = nWorldH / (nRow - 1.0);

    char sDenominator[ 32 ];
    itoaComma( nCel, sDenominator );
	
	drawString(15, 90, "Processing Buddahbrot", ILI9341_WHITE, ILI9341_DARKCYAN, 2);
				
    for( size_t iCol = 0; iCol < nCol; iCol++ )
    {
        
		const double x = gnWorldMinX + (iCol * dx);
		
        for(size_t iRow = 0; iRow < nRow; iRow++ )
        {
            progress++;
			const double y = gnWorldMinY + (iRow * dy);

            /* */ double r = 0., i = 0., s, j;

            iCel++;
			verbrose(nCol, nRow);
			
            for (int depth = 0; depth < gnMaxDepth; depth++)
            {
				
				s = (r*r - i*i) + x; // Zn+1 = Zn^2 + C<x,y>
                j = (2.0*r*i)   + y;

                r = s;
                i = j;
				
                if ((r*r + i*i) > 4.0) // escapes to infinity so trace path
                {
                    plot( x, y, nWorld2ImageX, nWorld2ImageY, gpGreyscaleTexels, gnWidth, gnHeight, gnMaxDepth );
					break;
                }
            }
			extern char anykey(void);
			
			if(anykey() == SEM_ACK)
				goto abort;
        }
	}
	abort:
	
    refresh_dsp(); 
	return nCel;
}




// ========================================================================

void buddahbrot_main(void);
void buddahbrot_main(void)
{
	
	AllocImageMemory( gnWidth, gnHeight );
	
	
	fillScreen(ILI9341_DARKCYAN);
    Buddhabrot();
	
	uint16_t *pRotatedTexels = gpGreyscaleTexels;
	
	const int nBytes =  gnImageArea * sizeof( uint16_t );
	pRotatedTexels = (uint16_t*) api_calloc(1, nBytes ); // 1x 16-bit channel: W

	Image_Greyscale16bitRotateRight( gpGreyscaleTexels, gnWidth, gnHeight, pRotatedTexels );

	int t = gnWidth; gnWidth = gnHeight; gnHeight = t;
	
	fillScreen(ILI9341_DARKCYAN);
    Image_Greyscale16bitToColor24bit( pRotatedTexels, gnWidth, gnHeight, gpChromaticTexels, gnGreyscaleBias, gnScaleR, gnScaleG, gnScaleB );
}


#endif /* BUDDAHBROT_H_ */